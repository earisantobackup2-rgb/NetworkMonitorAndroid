package com.example.networkmonitor.utils

import java.net.InetSocketAddress
import java.net.Socket

object NetworkUtils {

    fun ping(host: String): Boolean {
        return try {
            val process = Runtime.getRuntime().exec("ping -c 1 $host")
            process.waitFor() == 0
        } catch (e: Exception) {
            false
        }
    }

    fun checkTcp(host: String, port: Int): Boolean {
        return try {
            Socket().use {
                it.connect(InetSocketAddress(host, port), 2000)
            }
            true
        } catch (e: Exception) {
            false
        }
    }
}
