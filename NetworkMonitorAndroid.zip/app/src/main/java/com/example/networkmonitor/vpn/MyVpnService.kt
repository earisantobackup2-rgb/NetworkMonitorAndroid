package com.example.networkmonitor.vpn

import android.net.VpnService
import android.content.Intent

class MyVpnService : VpnService() {
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        return START_STICKY
    }
}
